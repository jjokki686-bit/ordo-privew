(function () {
  'use strict';
  const client = window.supabase.createClient(
    'https://jkikplybxtfgdejdmfoc.supabase.co',
    'sb_publishable_L6EWdDU0BIUNAbfCbZZ4Sg_BmBH5Z7c',
    { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: false } }
  );
  const redirectUrl = 'ordo://auth/callback';
  const state = { user: null, profile: null, requests: [], chats: [], groups: [], profiles: new Map(), tab: 'chats', active: null, messages: [], channel: null, showGroupForm: false };
  const byId = id => document.getElementById(id);
  const notify = message => window.showToast ? showToast(message) : alert(message);
  const display = userId => state.profiles.get(userId)?.display_name || '오르도 사용자';
  const other = pair => pair.user_a === state.user.id ? pair.user_b : pair.user_a;
  const el = (tag, className, text) => { const node = document.createElement(tag); if (className) node.className = className; if (text !== undefined) node.textContent = text; return node; };

  function prepareAuthScreen() {
    const form = byId('login-form');
    form.onsubmit = null;
    form.querySelector('label[for="login-password"]')?.setAttribute('hidden', '');
    form.querySelector('.auth-password').hidden = true;
    byId('login-password').required = false;
    byId('auth-signup-fields').hidden = true;
    byId('signup-confirm').required = false;
    byId('signup-agree').required = false;
    document.querySelectorAll('.social-login-examples,#auth-account-switch,#welcome-account-switch').forEach(node => node.remove());
    const preview = document.querySelector('#welcome>.secondary');
    preview?.remove();
    const authPreview = form.querySelector('.secondary[onclick*="enterPreview"]');
    authPreview?.remove();
    const primary = document.querySelector('#welcome>.btn-main');
    primary.textContent = '이메일로 시작하기';
    primary.onclick = () => showLogin('login');
    document.querySelector('#welcome>p').textContent = '이메일 인증으로 내 일정을 시작하세요.';
    byId('auth-title').textContent = '이메일로 시작하기';
    byId('auth-subtitle').textContent = '비밀번호 없이 이메일로 인증해요.';
    byId('login-note').textContent = '인증 메일의 링크를 누르면 앱으로 돌아옵니다.';
    byId('auth-submit').disabled = false;
    byId('auth-submit').textContent = '인증 메일 보내기';
    const codeRow = el('div'); codeRow.id = 'ordo-otp-row'; codeRow.hidden = true;
    const code = el('input'); code.id = 'ordo-otp-code'; code.inputMode = 'numeric'; code.autocomplete = 'one-time-code'; code.placeholder = '인증코드 6자리'; code.maxLength = 8;
    const verify = el('button', '', '코드 확인'); verify.type = 'button'; verify.onclick = verifyCode;
    codeRow.append(code, verify); byId('auth-submit').after(codeRow);
    form.addEventListener('submit', sendEmail, true);
    window.setAuthMode = function () { byId('auth-title').textContent = '이메일로 시작하기'; byId('auth-submit').textContent = '인증 메일 보내기'; };
  }

  async function sendEmail(event) {
    event.preventDefault(); event.stopImmediatePropagation();
    const email = byId('login-email').value.trim().toLowerCase();
    const button = byId('auth-submit'); button.disabled = true;
    byId('login-note').textContent = '인증 메일을 보내고 있어요…';
    try {
      const { error } = await client.auth.signInWithOtp({ email, options: { emailRedirectTo: redirectUrl, shouldCreateUser: true } });
      if (error) throw error;
      byId('login-note').textContent = '메일의 링크를 눌러 앱으로 돌아오세요. 인증코드가 보이면 아래에 입력할 수도 있어요.';
      byId('ordo-otp-row').hidden = false;
    } catch (error) { byId('login-note').textContent = '메일을 보내지 못했어요. 잠시 후 다시 시도해 주세요.'; console.error(error); }
    finally { button.disabled = false; }
  }

  async function verifyCode() {
    const email = byId('login-email').value.trim().toLowerCase();
    const token = byId('ordo-otp-code').value.trim();
    if (!email || !token) return notify('이메일과 인증코드를 입력해 주세요.');
    const { error } = await client.auth.verifyOtp({ email, token, type: 'email' });
    if (error) { notify('인증코드를 확인해 주세요.'); return; }
    await useSession();
  }

  async function acceptAuthUrl(raw) {
    try {
      const url = new URL(raw);
      if (url.protocol !== 'ordo:' || url.host !== 'auth') return;
      const hash = new URLSearchParams(url.hash.slice(1));
      const access_token = hash.get('access_token');
      const refresh_token = hash.get('refresh_token');
      if (access_token && refresh_token) {
        const { error } = await client.auth.setSession({ access_token, refresh_token });
        if (error) throw error;
      } else if (url.searchParams.get('code')) {
        const { error } = await client.auth.exchangeCodeForSession(url.searchParams.get('code'));
        if (error) throw error;
      } else if (url.searchParams.get('token_hash')) {
        const { error } = await client.auth.verifyOtp({ token_hash: url.searchParams.get('token_hash'), type: 'email' });
        if (error) throw error;
      } else return;
      await useSession();
    } catch (error) { console.error(error); notify('인증 링크를 확인하지 못했어요. 다시 메일을 요청해 주세요.'); }
  }

  async function useSession() {
    const { data: { session }, error } = await client.auth.getSession();
    if (error || !session?.user) {
      if (localStorage.getItem('ordo_current_user_id')) {
        localStorage.removeItem('ordo_current_user_id'); location.reload();
      }
      return;
    }
    if (localStorage.getItem('ordo_current_user_id') !== session.user.id) {
      localStorage.setItem('ordo_current_user_id', session.user.id);
      location.reload();
      return;
    }
    state.user = session.user;
    document.body.classList.add('ordo-account');
    await ensureProfile();
    enterPreview();
    byId('view-rooms').classList.add('online-mode');
    const profileName = state.profile?.display_name || '오르도 사용자';
    myProfile.name = profileName;
    myProfile.status = state.user.email || '';
    renderMe();
    addAccountTools();
    await refreshOnline();
  }

  async function ensureProfile() {
    const { data, error } = await client.from('ordo_profiles').select('user_id,display_name').eq('user_id', state.user.id).maybeSingle();
    if (error) throw error;
    if (data) { state.profile = data; return; }
    const username = 'u_' + state.user.id.replaceAll('-', '').slice(0, 18);
    const result = await client.from('ordo_profiles').insert({ user_id: state.user.id, username, display_name: '오르도 사용자' }).select('user_id,display_name').single();
    if (result.error) throw result.error;
    state.profile = result.data;
  }

  function addAccountTools() {
    if (byId('online-account-tools')) return;
    const box = el('div', 'online-account-tools'); box.id = 'online-account-tools';
    const edit = el('button', '', '표시 이름 변경'); edit.onclick = async () => {
      const name = prompt('친구에게 보일 이름', state.profile.display_name)?.trim();
      if (!name || name.length > 32) return;
      const { error } = await client.from('ordo_profiles').update({ display_name: name }).eq('user_id', state.user.id);
      if (error) return notify('이름을 변경하지 못했어요.');
      state.profile.display_name = name; myProfile.name = name; renderMe(); await refreshOnline();
    };
    const remove = el('button', '', '계정과 데이터 삭제'); remove.onclick = async () => {
      if (!confirm('계정과 서버에 저장된 프로필, 친구, 대화를 영구 삭제할까요?')) return;
      const { error } = await client.rpc('ordo_delete_my_account');
      if (error) return notify('계정을 삭제하지 못했어요. 다시 시도해 주세요.');
      await logout(); notify('계정이 삭제되었습니다.');
    };
    box.append(edit, remove); byId('view-me').insertBefore(box, byId('view-me').querySelector('.account-entry'));
  }

  async function refreshOnline() {
    if (!state.user) return;
    const uid = state.user.id;
    const [requests, chats, groups] = await Promise.all([
      client.from('ordo_friend_requests').select('id,user_a,user_b,requested_by,status,updated_at').or(`user_a.eq.${uid},user_b.eq.${uid}`).order('updated_at', { ascending: false }),
      client.from('ordo_direct_chats').select('id,user_a,user_b,created_at').or(`user_a.eq.${uid},user_b.eq.${uid}`).order('created_at', { ascending: false }),
      client.from('ordo_group_rooms').select('id,name,owner_id,created_at').order('created_at', { ascending: false })
    ]);
    if (requests.error || chats.error || groups.error) return notify('친구와 채팅을 불러오지 못했어요.');
    state.requests = requests.data || []; state.chats = chats.data || []; state.groups = groups.data || [];
    const ids = [...new Set([uid, ...state.requests.flatMap(row => [row.user_a, row.user_b]), ...state.chats.flatMap(row => [row.user_a, row.user_b])])];
    const profiles = await client.from('ordo_profiles').select('user_id,display_name').in('user_id', ids);
    if (!profiles.error) state.profiles = new Map((profiles.data || []).map(profile => [profile.user_id, profile]));
    renderOnline();
  }

  function renderOnline() {
    const root = byId('view-rooms');
    let ui = byId('online-room-ui');
    if (!ui) { ui = el('div'); ui.id = 'online-room-ui'; root.append(ui); }
    ui.replaceChildren();
    const head = el('div', 'online-head'); head.append(el('h2', '', state.active ? (state.active.kind === 'group' ? state.active.name : display(other(state.active))) : '채팅'));
    const refresh = el('button', '', '새로고침'); refresh.onclick = refreshOnline; head.append(refresh); ui.append(head);
    if (state.active) { renderConversation(ui); return; }
    const tabs = el('div', 'online-tabs');
    for (const [key, label] of [['chats','채팅'],['friends','친구']]) {
      const button = el('button', state.tab === key ? 'active' : '', label);
      button.onclick = () => { state.tab = key; renderOnline(); }; tabs.append(button);
    }
    ui.append(tabs);
    if (state.tab === 'friends') renderFriendsOnline(ui); else renderChatsOnline(ui);
  }

  function renderFriendsOnline(ui) {
    const form = el('form', 'online-form');
    const email = el('input'); email.type = 'email'; email.placeholder = '친구 이메일'; email.required = true; email.autocomplete = 'email';
    const add = el('button', '', '친구 추가'); add.type = 'submit'; form.append(email, add);
    form.onsubmit = async event => {
      event.preventDefault(); add.disabled = true;
      const { error } = await client.rpc('ordo_request_friend_email', { p_email: email.value.trim() });
      add.disabled = false;
      if (error) return notify('친구 요청을 보내지 못했어요.');
      email.value = ''; notify('상대 계정이 있으면 친구 요청이 전달됩니다.'); await refreshOnline();
    };
    ui.append(form);
    const accepted = state.requests.filter(row => row.status === 'accepted');
    const incoming = state.requests.filter(row => row.status === 'pending' && row.requested_by !== state.user.id);
    const outgoing = state.requests.filter(row => row.status === 'pending' && row.requested_by === state.user.id);
    section(ui, '친구', accepted, row => {
      const peer = other(row); const button = rowButton(display(peer), '1:1 대화하기'); button.onclick = () => openDirect(peer); return button;
    });
    section(ui, '받은 요청', incoming, row => {
      const peer = other(row); const item = rowButton(display(peer), '친구 요청');
      const yes = el('button', 'online-action', '수락'); yes.onclick = () => respond(row.id, true);
      const no = el('button', 'online-action', '거절'); no.onclick = () => respond(row.id, false);
      item.append(yes, no); return item;
    });
    section(ui, '보낸 요청', outgoing, row => rowButton(display(other(row)), '수락 대기 중'));
  }

  function renderChatsOnline(ui) {
    const create = el('button', 'online-create-group', state.showGroupForm ? '닫기' : '그룹 채팅 만들기');
    create.onclick = () => { state.showGroupForm = !state.showGroupForm; renderOnline(); };
    ui.append(create);
    if (state.showGroupForm) renderGroupForm(ui);
    const list = el('div', 'online-list');
    for (const group of state.groups) {
      const button = rowButton(group.name, '그룹 채팅'); button.onclick = () => openConversation({ ...group, kind: 'group' }); list.append(button);
    }
    for (const chat of state.chats) {
      const button = rowButton(display(other(chat)), '1:1 채팅'); button.onclick = () => openConversation(chat); list.append(button);
    }
    if (!list.children.length) list.append(el('p', 'online-empty', '친구를 추가하면 이곳에서 실시간 대화를 시작할 수 있어요.'));
    ui.append(list);
  }

  function renderGroupForm(ui) {
    const friends = state.requests.filter(row => row.status === 'accepted');
    const form = el('form', 'online-group-form');
    const name = el('input'); name.placeholder = '그룹 이름'; name.maxLength = 60; name.required = true;
    form.append(name);
    if (!friends.length) form.append(el('p', 'online-empty', '친구를 추가한 뒤 그룹을 만들 수 있어요.'));
    for (const row of friends) {
      const label = el('label'); const check = el('input'); check.type = 'checkbox'; check.value = other(row);
      label.append(check, document.createTextNode(display(other(row)))); form.append(label);
    }
    const create = el('button', '', '그룹 만들기'); create.type = 'submit'; create.disabled = !friends.length; form.append(create);
    form.onsubmit = async event => {
      event.preventDefault();
      const ids = [...form.querySelectorAll('input[type="checkbox"]:checked')].map(input => input.value);
      if (!ids.length) return notify('함께할 친구를 선택해 주세요.');
      create.disabled = true;
      const { data, error } = await client.rpc('ordo_create_group', { p_name: name.value.trim(), p_member_ids: ids });
      create.disabled = false;
      if (error) return notify('그룹을 만들지 못했어요.');
      state.showGroupForm = false; await refreshOnline();
      const group = state.groups.find(room => room.id === data);
      if (group) await openConversation({ ...group, kind: 'group' });
    };
    ui.append(form);
  }

  function section(root, title, items, render) {
    root.append(el('h3', 'online-section-title', title));
    const list = el('div', 'online-list');
    if (items.length) items.forEach(item => list.append(render(item)));
    else list.append(el('p', 'online-empty', '아직 없어요.'));
    root.append(list);
  }
  function rowButton(title, subtitle) {
    const button = el('div', 'online-row'); const text = el('span');
    text.append(el('strong', '', title), el('small', '', subtitle)); button.append(text); return button;
  }
  async function respond(id, accept) {
    const { error } = await client.rpc('ordo_respond_friend_request', { p_request_id: id, p_accept: accept });
    if (error) return notify('친구 요청을 처리하지 못했어요.');
    await refreshOnline();
  }
  async function openDirect(peer) {
    const { data, error } = await client.rpc('ordo_open_direct_chat', { other_user: peer });
    if (error) return notify('채팅을 시작하지 못했어요.');
    await refreshOnline();
    const chat = state.chats.find(row => row.id === data);
    if (chat) await openConversation(chat);
  }

  async function openConversation(chat) {
    if (state.channel) { await client.removeChannel(state.channel); state.channel = null; }
    state.active = chat;
    const group = chat.kind === 'group';
    const table = group ? 'ordo_group_messages' : 'ordo_messages';
    const key = group ? 'room_id' : 'chat_id';
    const { data, error } = await client.from(table).select(`id,${key},sender_id,body,created_at`)
      .eq(key, chat.id).order('created_at', { ascending: false }).limit(100);
    if (error) return notify('대화를 불러오지 못했어요.');
    state.messages = (data || []).reverse(); renderOnline();
    state.channel = client.channel('chat:' + chat.id)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table, filter: key + '=eq.' + chat.id }, payload => {
        if (!state.messages.some(message => message.id === payload.new.id)) state.messages.push(payload.new);
        renderOnline();
      }).subscribe();
  }

  function renderConversation(ui) {
    const chat = el('section', 'online-chat');
    const head = el('div', 'online-chat-head');
    const back = el('button', '', '‹ 뒤로'); back.onclick = async () => { if (state.channel) await client.removeChannel(state.channel); state.channel = null; state.active = null; renderOnline(); };
    const group = state.active.kind === 'group';
    head.append(back, el('strong', '', group ? state.active.name : display(other(state.active))));
    if (!group) {
      const peer = other(state.active);
      const report = el('button', '', '신고'); report.onclick = () => reportUser(peer);
      const block = el('button', '', '차단'); block.onclick = () => blockUser(peer);
      head.append(report, block);
    }
    chat.append(head);
    const messages = el('div', 'online-messages');
    if (!state.messages.length) messages.append(el('p', 'online-empty', '첫 메시지를 보내보세요.'));
    state.messages.forEach(message => {
      const mine = message.sender_id === state.user.id;
      const item = el('div', 'online-message' + (mine ? ' mine' : ''));
      if (group && !mine) {
        const sender = el('button', 'online-sender', display(message.sender_id));
        sender.onclick = () => { if (confirm('이 사용자를 신고할까요?')) reportUser(message.sender_id); };
        item.append(sender);
      }
      item.append(el('p', '', message.body), el('small', '', new Date(message.created_at).toLocaleString('ko-KR')));
      messages.append(item);
    });
    chat.append(messages);
    const compose = el('form', 'online-compose');
    const input = el('input'); input.maxLength = 4000; input.placeholder = '메시지 입력'; input.required = true;
    const send = el('button', '', '보내기'); send.type = 'submit'; compose.append(input, send);
    compose.onsubmit = async event => {
      event.preventDefault(); const body = input.value.trim(); if (!body) return;
      send.disabled = true;
      const table = group ? 'ordo_group_messages' : 'ordo_messages';
      const key = group ? 'room_id' : 'chat_id';
      const { data, error } = await client.from(table).insert({ [key]: state.active.id, sender_id: state.user.id, body }).select(`id,${key},sender_id,body,created_at`).single();
      send.disabled = false;
      if (error) return notify('메시지를 보내지 못했어요.');
      input.value = '';
      if (!state.messages.some(message => message.id === data.id)) state.messages.push(data);
      renderOnline();
    };
    chat.append(compose); ui.append(chat); messages.scrollTop = messages.scrollHeight;
  }
  async function reportUser(peer) {
    const reason = prompt('신고 사유를 입력해 주세요 (5자 이상)')?.trim();
    if (!reason || reason.length < 5 || reason.length > 500) return;
    const { error } = await client.from('ordo_reports').insert({ reporter_id: state.user.id, reported_user_id: peer, reason });
    notify(error ? '신고를 접수하지 못했어요.' : '신고가 접수되었습니다.');
  }
  async function blockUser(peer) {
    if (!confirm('이 사용자를 차단할까요? 서로 메시지를 보낼 수 없게 됩니다.')) return;
    const { error } = await client.from('ordo_blocks').insert({ blocker_id: state.user.id, blocked_id: peer });
    if (error) return notify('차단하지 못했어요.');
    if (state.channel) await client.removeChannel(state.channel);
    state.channel = null; state.active = null; notify('차단했습니다.'); renderOnline();
  }
  async function logout() {
    if (state.channel) await client.removeChannel(state.channel);
    await client.auth.signOut();
    localStorage.removeItem('ordo_current_user_id');
    location.reload();
  }
  window.ordoLogout = logout;

  prepareAuthScreen();
  const appPlugin = window.Capacitor?.registerPlugin?.('App');
  appPlugin?.addListener('appUrlOpen', event => acceptAuthUrl(event.url));
  appPlugin?.getLaunchUrl?.().then(result => { if (result?.url) acceptAuthUrl(result.url); }).catch(console.error);
  if (location.protocol === 'ordo:') acceptAuthUrl(location.href);
  client.auth.onAuthStateChange((event, session) => {
    if (session?.user && (!state.user || state.user.id !== session.user.id)) setTimeout(() => useSession().catch(console.error), 0);
  });
  useSession().catch(error => { console.error(error); notify('계정 정보를 불러오지 못했어요.'); });
})();
