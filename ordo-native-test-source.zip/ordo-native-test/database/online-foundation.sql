-- Existing ordo_* tables are already present in the connected Supabase project.
-- Apply this once to add email-only friend discovery, profiles, safety, and deletion.
create schema if not exists ordo_private;

create or replace function ordo_private.create_profile_for_new_user()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.ordo_profiles (user_id, username, display_name)
  values (new.id, 'u_' || substr(replace(new.id::text, '-', ''), 1, 18), '오르도 사용자')
  on conflict (user_id) do nothing;
  return new;
end;
$$;
drop trigger if exists ordo_profile_on_signup on auth.users;
create trigger ordo_profile_on_signup after insert on auth.users
for each row execute function ordo_private.create_profile_for_new_user();
-- The existing RLS policies restrict these operations to auth.uid().
-- This also lets accounts created before the trigger initialize their own profile.
grant insert, update on public.ordo_profiles to authenticated;

create or replace function public.ordo_request_friend_email(p_email text)
returns text language plpgsql security definer set search_path = '' as $$
declare caller uuid := auth.uid(); target uuid; existing public.ordo_friend_requests%rowtype;
begin
  if caller is null then raise exception 'Sign in required'; end if;
  if p_email is null or length(btrim(p_email)) > 254 or position('@' in p_email) < 2 then
    raise exception 'Enter a valid email address';
  end if;
  select id into target from auth.users where lower(email) = lower(btrim(p_email));
  -- A generic result avoids confirming whether an email address has an account.
  if target is null or target = caller then return 'sent'; end if;
  if exists (select 1 from public.ordo_blocks b where
    (b.blocker_id = caller and b.blocked_id = target) or
    (b.blocker_id = target and b.blocked_id = caller)) then return 'sent'; end if;
  select * into existing from public.ordo_friend_requests r
    where r.user_a = least(caller,target) and r.user_b = greatest(caller,target) for update;
  if found then
    if existing.status = 'pending' and existing.requested_by <> caller then
      update public.ordo_friend_requests set status = 'accepted', updated_at = now() where id = existing.id;
    elsif existing.status = 'rejected' then
      update public.ordo_friend_requests set status = 'pending', requested_by = caller,
        updated_at = now() where id = existing.id;
    end if;
  else
    insert into public.ordo_friend_requests (user_a,user_b,requested_by)
    values (least(caller,target),greatest(caller,target),caller);
  end if;
  return 'sent';
end;
$$;
revoke all on function public.ordo_request_friend_email(text) from public, anon;
grant execute on function public.ordo_request_friend_email(text) to authenticated;

create table if not exists public.ordo_blocks (
  blocker_id uuid not null references auth.users(id) on delete cascade,
  blocked_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (blocker_id, blocked_id),
  check (blocker_id <> blocked_id)
);
create index if not exists ordo_blocks_blocked_idx on public.ordo_blocks (blocked_id);
alter table public.ordo_blocks enable row level security;
create policy "Read own blocks" on public.ordo_blocks for select to authenticated
  using (blocker_id = (select auth.uid()));
create policy "Create own blocks" on public.ordo_blocks for insert to authenticated
  with check (blocker_id = (select auth.uid()));
create policy "Remove own blocks" on public.ordo_blocks for delete to authenticated
  using (blocker_id = (select auth.uid()));
grant select, insert, delete on public.ordo_blocks to authenticated;

create table if not exists public.ordo_reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references auth.users(id) on delete cascade,
  reported_user_id uuid not null references auth.users(id) on delete cascade,
  message_id uuid references public.ordo_messages(id) on delete set null,
  reason text not null check (length(btrim(reason)) between 5 and 500),
  status text not null default 'pending' check (status in ('pending','reviewed','resolved')),
  created_at timestamptz not null default now(),
  check (reporter_id <> reported_user_id)
);
create index if not exists ordo_reports_status_idx on public.ordo_reports (status, created_at);
alter table public.ordo_reports enable row level security;
create policy "Read own reports" on public.ordo_reports for select to authenticated
  using (reporter_id = (select auth.uid()));
create policy "Submit own reports" on public.ordo_reports for insert to authenticated
  with check (reporter_id = (select auth.uid()) and status = 'pending' and (
    message_id is null or exists (
      select 1 from public.ordo_messages m join public.ordo_direct_chats c on c.id = m.chat_id
      where m.id = message_id and m.sender_id = reported_user_id
        and (c.user_a = (select auth.uid()) or c.user_b = (select auth.uid()))
    )
  ));
grant select, insert on public.ordo_reports to authenticated;

create or replace function ordo_private.reject_blocked_message()
returns trigger language plpgsql security definer set search_path = '' as $$
declare other_user uuid;
begin
  select case when c.user_a = new.sender_id then c.user_b else c.user_a end
    into other_user from public.ordo_direct_chats c where c.id = new.chat_id;
  if exists (select 1 from public.ordo_blocks b where
    (b.blocker_id = new.sender_id and b.blocked_id = other_user) or
    (b.blocker_id = other_user and b.blocked_id = new.sender_id)) then
    raise exception 'Messaging unavailable';
  end if;
  return new;
end;
$$;
drop trigger if exists ordo_message_block_check on public.ordo_messages;
create trigger ordo_message_block_check before insert on public.ordo_messages
for each row execute function ordo_private.reject_blocked_message();

create or replace function public.ordo_delete_my_account()
returns void language plpgsql security definer set search_path = '' as $$
declare caller uuid := auth.uid();
begin
  if caller is null then raise exception 'Sign in required'; end if;
  delete from auth.users where id = caller;
end;
$$;
revoke all on function public.ordo_delete_my_account() from public, anon;
grant execute on function public.ordo_delete_my_account() to authenticated;
