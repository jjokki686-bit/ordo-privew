create table public.ordo_group_rooms (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (length(btrim(name)) between 1 and 60),
  created_at timestamptz not null default now()
);
create table public.ordo_group_members (
  room_id uuid not null references public.ordo_group_rooms(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  joined_at timestamptz not null default now(),
  primary key (room_id,user_id)
);
create index ordo_group_members_user_idx on public.ordo_group_members (user_id,room_id);
create table public.ordo_group_messages (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.ordo_group_rooms(id) on delete cascade,
  sender_id uuid not null references auth.users(id) on delete cascade,
  body text not null check (length(btrim(body)) between 1 and 4000),
  created_at timestamptz not null default now()
);
create index ordo_group_messages_room_time_idx on public.ordo_group_messages (room_id,created_at desc);

alter table public.ordo_group_rooms enable row level security;
alter table public.ordo_group_members enable row level security;
alter table public.ordo_group_messages enable row level security;
create policy "Read own group memberships" on public.ordo_group_members for select to authenticated
  using (user_id = (select auth.uid()));
create policy "Members read groups" on public.ordo_group_rooms for select to authenticated
  using (exists (select 1 from public.ordo_group_members m where m.room_id=id and m.user_id=(select auth.uid())));
create policy "Members read group messages" on public.ordo_group_messages for select to authenticated
  using (exists (select 1 from public.ordo_group_members m where m.room_id=ordo_group_messages.room_id and m.user_id=(select auth.uid())));
create policy "Members send group messages" on public.ordo_group_messages for insert to authenticated
  with check (sender_id=(select auth.uid()) and exists (
    select 1 from public.ordo_group_members m where m.room_id=ordo_group_messages.room_id and m.user_id=(select auth.uid())
  ));
grant select on public.ordo_group_rooms,public.ordo_group_members to authenticated;
grant select,insert on public.ordo_group_messages to authenticated;

create or replace function public.ordo_create_group(p_name text,p_member_ids uuid[])
returns uuid language plpgsql security definer set search_path = '' as $$
declare caller uuid := auth.uid(); room uuid; invited uuid;
begin
  if caller is null then raise exception 'Sign in required'; end if;
  if p_name is null or length(btrim(p_name)) not between 1 and 60 then raise exception 'Invalid group name'; end if;
  if coalesce(array_length(p_member_ids,1),0) > 49 then raise exception 'Too many members'; end if;
  if caller = any(coalesce(p_member_ids,'{}'::uuid[])) then raise exception 'Do not invite yourself'; end if;
  if (select count(distinct member_id) from unnest(coalesce(p_member_ids,'{}'::uuid[])) member_id)
       <> coalesce(array_length(p_member_ids,1),0) then raise exception 'Duplicate members'; end if;
  foreach invited in array coalesce(p_member_ids,'{}'::uuid[]) loop
    if not exists (select 1 from public.ordo_friend_requests f
      where f.user_a=least(caller,invited) and f.user_b=greatest(caller,invited) and f.status='accepted') then
      raise exception 'All invitees must be friends';
    end if;
    if exists (select 1 from public.ordo_blocks b where
      (b.blocker_id=caller and b.blocked_id=invited) or (b.blocker_id=invited and b.blocked_id=caller)) then
      raise exception 'A blocked user cannot be invited';
    end if;
  end loop;
  insert into public.ordo_group_rooms(owner_id,name) values(caller,btrim(p_name)) returning id into room;
  insert into public.ordo_group_members(room_id,user_id) values(room,caller);
  insert into public.ordo_group_members(room_id,user_id)
    select room,member_id from unnest(coalesce(p_member_ids,'{}'::uuid[])) member_id;
  return room;
end;
$$;
revoke all on function public.ordo_create_group(text,uuid[]) from public,anon;
grant execute on function public.ordo_create_group(text,uuid[]) to authenticated;
alter publication supabase_realtime add table public.ordo_group_messages;
