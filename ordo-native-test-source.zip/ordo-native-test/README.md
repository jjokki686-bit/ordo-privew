# 오르도 iPhone 앱

Capacitor 8 기반 iOS 프로젝트입니다. 화면 소스는 `web/index.html`, 이메일 로그인과 서버 채팅 코드는 `web/online.js`, 서버 SQL은 `database/online-foundation.sql`과 `database/group-chat.sql`입니다.

## 현재 연결된 기능

- Supabase 프로젝트 `Ordo -`에서 이메일 매직 링크 회원가입과 로그인
- 이메일 주소로 친구 요청, 수락·거절, 1:1 및 친구 초대 그룹 실시간 텍스트 채팅
- 사용자 신고, 차단, 계정 삭제
- 개인 일정·루틴은 계정별 기기 저장소에 보관합니다. 기존 `ordo_v3_*` 미리보기 데이터는 서버에 자동 업로드되지 않습니다.

새 계정에는 예시 일정·친구·채팅이 생성되지 않습니다. 서버 채팅은 현재 텍스트만 지원합니다. 사진·파일 공유, 일정 제안, 소셜 로그인, 푸시 알림과 유료 플랜은 실제 서비스로 완성되지 않았습니다.

## 윈도우에서 확인

Node.js 22 이상에서 `npm ci`, `npm run build`, `npm run check`, `npx cap sync ios`를 실행합니다. `.github/workflows/ios-compile.yml`을 GitHub Actions에서 수동 실행하면 macOS 시뮬레이터용 서명 없는 컴파일을 확인할 수 있습니다. 그 결과물은 아이폰에 설치하거나 App Store에 제출할 수 없습니다.

## 두 대의 iPhone에서 무료 테스트

Apple 무료 Personal Team은 최대 3대의 기기를 등록할 수 있으므로 두 대의 iPhone 테스트가 기기 수 한도 안에 듭니다. 각 기기를 Mac의 Xcode로 설치해야 하며, 무료 프로비저닝은 7일 후 만료되어 다시 빌드하고 설치해야 합니다. 다운로드 링크나 TestFlight 배포 방식은 아닙니다.

Mac에는 **Xcode 26 이상**과 **Node.js 22 이상**이 필요합니다. 이 프로젝트는 Swift Package Manager를 사용하므로 CocoaPods는 필요하지 않습니다. 준비된 Mac에서 이 폴더를 열고 `npm ci`, `npm run ios:sync`, `npm run ios:open`을 차례로 실행합니다. Xcode에서 App 대상의 **Signing & Capabilities → Team**을 본인 무료 Personal Team으로 설정하고, 고유한 Bundle Identifier를 선택합니다. 첫 번째 iPhone을 연결해 실행한 뒤 두 번째 iPhone을 연결해 같은 방법으로 실행합니다. 각 iPhone에서 개발자 모드와 기기 신뢰 설정이 필요할 수 있습니다.

Xcode가 설치되지 않은 Mac이라면 설치와 첫 iOS 빌드에 시간이 오래 걸릴 수 있습니다. Mac을 쓸 수 없으면 Windows에서 소스를 계속 수정하고 웹 자산 빌드까지 확인할 수 있지만, 무료 Personal Team으로 iPhone 설치를 완료할 수는 없습니다.

## 이메일 링크에서 앱으로 돌아오기

`ios/App/App/Info.plist`에 `ordo://` URL 스킴을 등록했습니다. 연결된 Supabase 프로젝트의 **Authentication → URL Configuration → Redirect URLs**에 `ordo://auth/callback`을 추가해야 메일 링크가 앱으로 돌아옵니다. 이 대시보드 설정은 아직 확인되지 않았습니다.

기본 매직 링크 메일 템플릿을 사용합니다. 이메일에 코드를 함께 표시하려면 **Authentication → Email Templates → Magic Link** 템플릿에 `{{ .Token }}`을 포함하세요. 앱에는 코드 입력도 준비되어 있습니다. 운영 환경에서는 [Supabase의 Auth 메일 발송 설정](https://supabase.com/docs/guides/auth/auth-smtp)을 검토하고 자체 SMTP를 연결해야 합니다.

## 출시 전에 할 일

1. Apple Developer Program 계정과 App Store Connect 앱 항목을 준비합니다.
2. 소유한 고유 Bundle ID로 임시값 `com.ordo.prototype`을 바꾸고 Signing을 설정합니다.
3. macOS의 Xcode 또는 macOS CI에서 서명된 빌드를 만들고 실제 아이폰에서 이메일 복귀와 두 계정 간 채팅을 검증합니다.
4. TestFlight에서 신고·차단·계정 삭제를 포함한 기기 테스트를 마칩니다.
5. 개인정보처리방침 URL, 고객지원 연락처, App Store 스크린샷과 심사 메모를 준비합니다.
6. 채팅 콘텐츠의 신고 대응과 금지 콘텐츠 필터링 운영 절차를 마련합니다.

현재 Windows 환경에서는 iOS 기기 빌드·서명과 실기기 동작을 검증할 수 없습니다. Xcode Cloud의 최초 설정에도 Xcode가 필요하므로, Mac을 직접 사용하지 않는다면 macOS CI와 Apple 서명 자격 증명을 별도로 구성해야 합니다.
