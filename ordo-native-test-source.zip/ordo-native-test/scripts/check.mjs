import { readFile, stat } from 'node:fs/promises';
import assert from 'node:assert/strict';

const source = await readFile(new URL('../web/index.html', import.meta.url), 'utf8');
const built = await readFile(new URL('../www/index.html', import.meta.url), 'utf8');
const config = JSON.parse(await readFile(new URL('../capacitor.config.json', import.meta.url), 'utf8'));
assert.equal(source, built, 'Build must preserve the current UI exactly');
assert.equal(config.webDir, 'www');
for (const id of ['app', 'nav', 'view-cal', 'view-me', 'sheet-room', 'sheet-chat-profile']) {
  assert.match(built, new RegExp(`id="${id}"`), `Missing ${id}`);
}
assert.ok((await stat(new URL('../www/ordo-icon.svg', import.meta.url))).size > 0);
console.log('Build check passed: UI source matches output and key screens are present.');
