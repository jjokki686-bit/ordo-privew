import { mkdir, readFile, writeFile, copyFile } from 'node:fs/promises';
const source = new URL('../web/', import.meta.url);
const output = new URL('../www/', import.meta.url);
await mkdir(output, { recursive: true });
let html = await readFile(new URL('index.html', source), 'utf8');
if (!html.includes('<head>') && !html.includes('<head ')) {
  throw new Error('Capacitor requires a <head> in index.html');
}
if (!html.includes('id="app"')) {
  throw new Error('Expected Ordo app root is missing');
}
await writeFile(new URL('index.html', output), html, 'utf8');
await copyFile(new URL('ordo-icon.svg', source), new URL('ordo-icon.svg', output));
await copyFile(new URL('online.js', source), new URL('online.js', output));
await copyFile(new URL('online.css', source), new URL('online.css', output));
await copyFile(new URL('../node_modules/@supabase/supabase-js/dist/umd/supabase.js', import.meta.url), new URL('supabase.js', output));
await writeFile(new URL('ordo.webmanifest', output), JSON.stringify({
  id: '/',
  name: '오르도',
  short_name: 'ordo',
  start_url: './index.html',
  scope: './',
  display: 'standalone',
  background_color: '#f5f4ef',
  theme_color: '#11130f',
  icons: [{ src: './ordo-icon.svg', sizes: 'any', type: 'image/svg+xml' }]
}, null, 2) + '\n', 'utf8');
console.log('Built Ordo web assets in www/');
